import React from "react";
import { FiGrid, FiBell, FiMail, FiUser, FiSettings } from "react-icons/fi";
import Sidebar from "./components/Sidebar";
import ChatWindow from "./components/ChatWindow";
import Notifications from "./components/Notifications";

export default function ChatDashboard() {
  return (
    <div className="hm-root">
      {/* Top bar */}
      <div className="hm-topbar">
        <div className="hm-brand">Chat Bot</div>
        <div className="hm-top-icons">
          <FiGrid />
          <FiMail />
          <FiBell />
          <FiUser />
          <FiSettings />
        </div>
      </div>

      {/* Main 3-column layout */}
      <div className="hm-shell">
        <Sidebar />
        <ChatWindow />
        <Notifications />
      </div>
    </div>
  );
}
