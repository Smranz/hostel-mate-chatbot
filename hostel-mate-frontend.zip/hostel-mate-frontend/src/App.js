import React, { useState } from "react";

function App() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");

  // --- Send text message to backend ---
  const sendMessage = async () => {
    if (!input.trim()) return;

    try {
      const res = await fetch("http://127.0.0.1:8000/chatbot/text/", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: input }),
      });

      const data = await res.json();

      setMessages((prev) => [
        ...prev,
        { sender: "You", text: input },
        { sender: "Bot", text: data.response || "No reply" },
      ]);

      setInput("");
    } catch (error) {
      console.error("Error sending message:", error);
    }
  };

  // --- Handle voice input using Web Speech API ---
  const handleVoice = () => {
    const recognition =
      new (window.SpeechRecognition || window.webkitSpeechRecognition)();
    recognition.lang = "en-US";
    recognition.start();

    recognition.onresult = async (event) => {
      const transcript = event.results[0][0].transcript;

      setMessages((prev) => [...prev, { sender: "You (Voice)", text: transcript }]);

      try {
        const res = await fetch("http://127.0.0.1:8000/chatbot/voice/", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ message: transcript }),
        });
        const data = await res.json();

        setMessages((prev) => [
          ...prev,
          { sender: "Bot (Voice)", text: data.response || "No reply" },
        ]);

        // Speak out bot response
        const speech = new SpeechSynthesisUtterance(data.response);
        window.speechSynthesis.speak(speech);
      } catch (error) {
        console.error("Voice chat error:", error);
      }
    };
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-100">
      <h1 className="text-2xl font-bold text-blue-600 mb-4">
        🤖 Hostel Mate Chatbot
      </h1>

      {/* Chat Window */}
      <div className="w-full max-w-md h-96 overflow-y-auto bg-white shadow-md rounded-lg p-4 mb-4">
        {messages.map((msg, idx) => (
          <div
            key={idx}
            className={`mb-2 ${
              msg.sender.includes("You") ? "text-right" : "text-left"
            }`}
          >
            <span
              className={`inline-block px-3 py-2 rounded-lg ${
                msg.sender.includes("You")
                  ? "bg-blue-500 text-white"
                  : "bg-gray-300 text-black"
              }`}
            >
              {msg.text}
            </span>
          </div>
        ))}
      </div>

      {/* Input + Voice */}
      <div className="flex w-full max-w-md items-center">
        <input
          type="text"
          placeholder="Type your message..."
          className="flex-1 border rounded-l-lg px-3 py-2"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && sendMessage()}
        />
        <button
          onClick={sendMessage}
          className="bg-blue-500 text-white px-4 py-2 rounded-r-lg"
        >
          Send
        </button>
        <button
          onClick={handleVoice}
          className="ml-2 bg-green-500 text-white px-4 py-2 rounded-lg"
        >
          🎤
        </button>
      </div>
    </div>
  );
}

export default App;
