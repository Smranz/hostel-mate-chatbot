import React from "react";

function Chatbot() {
  return (
    <div className="p-4 bg-white rounded-2xl shadow">
      <p className="text-gray-700">🤖 Chatbot is ready!</p>
    </div>
  );
}

export default Chatbot;
