import React from "react";

const notifs = [
  { who: "Nathan", text: "Nullam facilisis velit eu nulla dictum volutpat.", when: "23 hours ago" },
  { who: "Christian", text: "Proin iaculis eros non odio ornare efficitur.", when: "3 hours ago" },
  { who: "Dylan", text: "Morbi quis ex arcu auctor sagittis.", when: "Yesterday" },
  { who: "Nathan", text: "Nullam facilisis velit eu nulla dictum volutpat.", when: "23 hours ago" },
];

const suggestions = ["Austin", "Thomas", "Chase", "Xavier"];

export default function Notifications() {
  return (
    <aside className="hm-right">
      <div className="hm-right-block">
        <div className="hm-right-title">Notification</div>
        <div className="hm-right-list">
          {notifs.map((n, i) => (
            <div key={i} className="hm-right-row">
              <div className="hm-avatar small" />
              <div className="hm-right-meta">
                <div className="hm-right-who">{n.who}</div>
                <div className="hm-right-text">{n.text}</div>
              </div>
              <div className="hm-right-time">{n.when}</div>
            </div>
          ))}
        </div>
      </div>

      <div className="hm-right-block">
        <div className="hm-right-title">Suggestions</div>
        <div className="hm-right-list">
          {suggestions.map((s, i) => (
            <div key={i} className="hm-right-row">
              <div className="hm-avatar small" />
              <div className="hm-right-who">{s}</div>
              <button className="hm-add">Add</button>
            </div>
          ))}
        </div>
      </div>
    </aside>
  );
}
