// src/components/ChatWindow.jsx
import React from "react";
import Chatbot from "../Chatbot";

function ChatWindow() {
  return (
    <div className="chat-window bg-white rounded-2xl shadow p-4 h-full flex flex-col">
      <h2 className="text-xl font-semibold mb-4 text-gray-700">Chat</h2>
      <div className="flex-1 overflow-y-auto">
        <Chatbot />
      </div>
    </div>
  );
}

export default ChatWindow;
