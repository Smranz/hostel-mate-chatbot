import React from "react";

const fakeList = [
  { name: "Mical Clark", last: "Nullam facilisis velit.", time: "10:00pm" },
  { name: "Colin Nathan", last: "Nullam facilisis velit.", time: "10:00pm" },
  { name: "Nathan Johen", last: "Nullam facilisis velit.", time: "10:00pm" },
  { name: "Semi Doe", last: "Nullam facilisis velit.", time: "10:00pm" },
  { name: "Mical", last: "Nullam facilisis velit.", time: "10:00pm" },
  { name: "John Doe", last: "Nullam facilisis velit.", time: "10:00pm" },
];

export default function Sidebar() {
  return (
    <aside className="hm-left">
      <div className="hm-left-tabs">
        <button className="active">Direct</button>
        <button>Group</button>
        <button>Public</button>
      </div>

      <div className="hm-search">
        <input placeholder="Search" />
      </div>

      <div className="hm-chatlist">
        {fakeList.map((u, i) => (
          <div className="hm-chatrow" key={i}>
            <div className="hm-avatar" />
            <div className="hm-chatmeta">
              <div className="hm-chatname">{u.name}</div>
              <div className="hm-chatlast">{u.last}</div>
            </div>
            <div className="hm-chattime">{u.time}</div>
          </div>
        ))}
      </div>
    </aside>
  );
}
